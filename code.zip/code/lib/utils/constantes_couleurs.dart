import 'package:flutter/material.dart';

class ConstantesCouleurs {
  static const Color orange = Color(0xFFFF6600);

}
